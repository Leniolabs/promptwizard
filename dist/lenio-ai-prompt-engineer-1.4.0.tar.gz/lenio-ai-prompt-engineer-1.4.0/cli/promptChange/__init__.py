from .uppercase import *
from .lowercase import *
from .random_uppercase import *
from .random_lowercase import *
from .random_uppercase_word import *
from .random_lowercase_word import *
from .synonymous_prompt import *
from .grammatical_errors import *