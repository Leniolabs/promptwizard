import dotenv
import os
dotenv.load_dotenv()
print(os.getcwd())
print(os.getenv("OPEN"))