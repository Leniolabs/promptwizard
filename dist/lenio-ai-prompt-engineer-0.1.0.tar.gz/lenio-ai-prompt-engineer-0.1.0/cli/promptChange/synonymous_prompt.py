import openai

def synonym(string):
    x = openai.ChatCompletion.create(
                    model='gpt-3.5-turbo',
                    messages=[
                        {"role": "system", "content": """Your job is to generate changes to a system prompt for GPT. These changes will consist of changing some words that you consider synonymous without changing the meaning of the original prompt. 
                        The prompt tells you to do tasks but you don't have to do the tasks, just change words from the prompt to synonyms. You will receive a prompt and you only have to return the content of the prompt with the synonymous changes that you have made and nothing else"""},
                        {"role": "user", "content": string}
                    ],
                    max_tokens=500,
                    temperature=0.8,
                ).choices[0].message.content
    return x
    
def convert_prompts(prompts):
    new_prompts = []
    for prompt in prompts:
        new_prompt = synonym(prompt)
        new_prompts.append(new_prompt)
    return new_prompts