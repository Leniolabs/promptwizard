import matplotlib.pyplot as plt
import numpy as np

#  Datos para 'anagrams'
less_130_classification_equal_includes_anagrams = [76, 80, 0]
between_130_250_classification_equal_includes_anagrams = [100, 92, 20]
more_250_classification_equal_includes_anagrams = [96, 96, 92]

# Datos para 'first-letters'
less_130_equal_includes_first_letters = [70, 35]
between_130_250_equal_includes_first_letters = [45, 50]
more_250_equal_includes_first_letters = [85, 70]

# Datos para 'largest-country'
less_130_equal_includes_largest_country = [5.18, 0]
between_130_250_equal_includes_largest_country = [14.81, 30.87]
more_250_equal_includes_largest_country = [22.96, 26.66]

# Datos para 'palindrome-check'
less_130_classification_equal_includes_palindrome_check = [80, 80, 0]
between_130_250_classification_equal_includes_palindrome_check = [100, 100, 20]
more_250_classification_equal_includes_palindrome_check = [100, 100, 88]

# Datos para 'sentence-reversal'
less_130_equal_includes_sentence_reversal = [0, 0]
between_130_250_equal_includes_sentence_reversal = [20, 0]
more_250_equal_includes_sentence_reversal = [0, 28]

# Configuración del gráfico
fig, ax = plt.subplots()

# Configuración de las barras agrupadas
bar_width = 0.2
index = np.arange(2)
opacity = 0.8

# Gráfico 'less_130_classification_equal_includes_anagrams'
rects1 = ax.bar(index, less_130_equal_includes_sentence_reversal, bar_width, alpha=opacity, label='<130')

# Gráfico 'between_130_250_classification_equal_includes_anagrams'
rects2 = ax.bar(index + bar_width, between_130_250_equal_includes_sentence_reversal, bar_width, alpha=opacity, label='130-250')

# Gráfico 'more_250_classification_equal_includes_anagrams'
rects3 = ax.bar(index + 2 * bar_width, more_250_equal_includes_sentence_reversal, bar_width, alpha=opacity, label='>250')

ax.set_xlabel('Categories')
ax.set_ylabel('Rating')
ax.set_title('Accuracy per prompt length - sentence_reversal')
ax.set_xticks(index + bar_width)
ax.set_xticklabels(['Equal', 'Includes'])



# Etiquetas para las barras
for rects in [rects1, rects2, rects3]:
    for rect in rects:
        height = rect.get_height()
        if height == 0:
            ax.annotate('0%', xy=(rect.get_x() + rect.get_width() / 2, 3), ha='center', va='bottom', fontsize=8)

# Línea de referencia en 0
ax.axhline(0, color='gray', linestyle='dashed', linewidth=0.5)

ax.legend()


# Ajustes finales del gráfico
plt.tight_layout()

# Guardar el gráfico como una imagen PNG
plt.savefig('/Users/camilo.basualdo/Documents/prompt-engineer/lenio-ai-prompt-engineer/cli/evals/sentence-reversal.png')

# Mostrar el gráfico
plt.show()